# full-scan-cli

test scanning scan-cli files w/ yml properties file
